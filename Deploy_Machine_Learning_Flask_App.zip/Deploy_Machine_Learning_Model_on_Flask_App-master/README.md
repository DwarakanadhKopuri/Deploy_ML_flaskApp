# Deploy_Machine_Learning_Model_on_Flask_App
It's a Git Repo containing source code, supported docker files, multiple linear regression pickle file and other related contents of Flask App and Machine Learning Model.
